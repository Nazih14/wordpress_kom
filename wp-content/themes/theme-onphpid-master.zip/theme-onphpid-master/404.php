<?php
get_header();?>
<div class="page-404">
	<div class="container text-center">
		<h2 class="title-404">404 Not Found!!!</h2>
		<p class="descript">Sorry! Not Found</p>
	</div>
</div>
<?php
get_footer();?>